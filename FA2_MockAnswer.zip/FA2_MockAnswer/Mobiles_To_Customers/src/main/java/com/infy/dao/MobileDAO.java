package com.infy.dao;

import java.util.List;

import com.infy.model.Customer;
import com.infy.model.Mobile;

public interface MobileDAO {
	
	public List<Mobile> getMobileDetails() throws Exception;
	
	
}
