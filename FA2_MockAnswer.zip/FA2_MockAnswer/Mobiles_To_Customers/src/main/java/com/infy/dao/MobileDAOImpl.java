package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.infy.entity.CustomerEntity;
import com.infy.entity.MobileEntity;
import com.infy.model.Customer;
import com.infy.model.Mobile;


@Repository(value = "mobileDAO")
public class MobileDAOImpl implements MobileDAO {

	@PersistenceContext
	private EntityManager entityManager;

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Mobile> getMobileDetails() throws Exception {
		Query q = entityManager
				.createQuery("SELECT m FROM MobileEntity m");
		
		List<MobileEntity> mobileEntityList = q.getResultList();

		List<Mobile> mobileList = new ArrayList<>();
		if (mobileEntityList.isEmpty()) {
			return mobileList;
		}
		for (MobileEntity ce : mobileEntityList) {
			Mobile mobile = new Mobile();
			mobile.setMobileId(ce.getMobileId());
			mobile.setCompanyName(ce.getCompanyName());
			mobile.setModelName(ce.getModelName());
			mobile.setRam(ce.getRam());
			mobile.setOs(ce.getOs());
			mobile.setPrice(ce.getPrice());
			
			mobileList.add(mobile);
			
		}
		return mobileList;
	}

	
}
