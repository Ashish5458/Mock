package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.infy.entity.CustomerEntity;
import com.infy.entity.MobileEntity;
import com.infy.model.Customer;

import com.infy.model.Mobile;


@Repository(value = "customerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@PersistenceContext
	private EntityManager entityManager;

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public Customer getCustomerByCustomerId(Integer customerId) throws Exception {
		Query q = entityManager
				.createQuery("SELECT c FROM CustomerEntity c where c.customerId=:customerid");
		q.setParameter("customerid", customerId);
		
		CustomerEntity customerEntity = (CustomerEntity)q.getSingleResult();

		Customer customer = new Customer();
		if (customerEntity==null) {
			return null;
		}
		
			
			customer.setCustomerId(customerEntity.getCustomerId());
			customer.setCustomerName(customerEntity.getCustomerName());
			customer.setAddress(customerEntity.getAddress());
			Mobile mobile = new Mobile();
						
			mobile.setMobileId(customerEntity.getMobile().getMobileId());
			mobile.setCompanyName(customerEntity.getMobile().getCompanyName());
			mobile.setModelName(customerEntity.getMobile().getModelName());
			mobile.setRam(customerEntity.getMobile().getRam());
			mobile.setOs(customerEntity.getMobile().getOs());
			mobile.setPrice(customerEntity.getMobile().getPrice());
			customer.setMobile(mobile);
			
		
		return customer;
	}

	@Override
	public List<Customer> getCustomerDetails() throws Exception {
		
		Query q = entityManager
				.createQuery("SELECT c FROM CustomerEntity c");
		
		List<CustomerEntity> customerEntityList = q.getResultList();

		List<Customer> customerList = new ArrayList<>();
		if (customerEntityList.isEmpty()) {
			return customerList;
		}
		for (CustomerEntity ce : customerEntityList) {
			Customer customer = new Customer();
			customer.setCustomerId(ce.getCustomerId());
			customer.setCustomerName(ce.getCustomerName());
			customer.setAddress(ce.getAddress());
			Mobile mobile = new Mobile();
						
			mobile.setMobileId(ce.getMobile().getMobileId());
			mobile.setCompanyName(ce.getMobile().getCompanyName());
			mobile.setModelName(ce.getMobile().getModelName());
			mobile.setRam(ce.getMobile().getRam());
			mobile.setOs(ce.getMobile().getOs());
			mobile.setPrice(ce.getMobile().getPrice());
			customer.setMobile(mobile);
			
			customerList.add(customer);
			
		}
		return customerList;
	}
}
