package com.infy.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.CustomerDAO;
import com.infy.dao.MobileDAO;
import com.infy.model.Customer;


@Service(value = "customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;

	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Customer> getCustomerDetails() throws Exception {
		List<Customer> customerList = customerDAO.getCustomerDetails();
		if (customerList.isEmpty()) {
			throw new Exception("Service.FAILURE");
		}

		return customerList;
		
	}
	
	@Override
	public Customer getCustomerByCustomerId(Integer customerId) throws Exception {
		Customer customer= customerDAO.getCustomerByCustomerId(customerId);
		if (customer==null) {
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		}

		return customer;
		
	}

}
