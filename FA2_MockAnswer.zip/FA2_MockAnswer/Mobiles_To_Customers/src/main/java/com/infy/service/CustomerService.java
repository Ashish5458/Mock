package com.infy.service;

import java.util.List;

import com.infy.model.Customer;

public interface CustomerService {

	public List<Customer> getCustomerDetails() throws Exception;
	
	public Customer getCustomerByCustomerId(Integer customerId) throws Exception;

	

}
